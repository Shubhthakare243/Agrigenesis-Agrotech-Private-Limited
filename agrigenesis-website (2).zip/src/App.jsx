import React from "react";
import { motion } from "framer-motion";
import { Leaf, Factory, FlaskConical, Truck, Phone, Mail, MapPin, Linkedin, Twitter } from "lucide-react";
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";

// Logo image component
const Logo = ({ className }) => (
  <div className={`flex flex-col items-center ${className ?? ""}`}>
    <img src="/logo.png" alt="Agrigenesis Logo" className="h-20 w-20 md:h-28 md:w-28 object-contain" />
    <div className="mt-3 text-center">
      <div className="text-lg md:text-2xl font-bold">AGRIGENESIS</div>
      <div className="text-[10px] md:text-xs tracking-[0.3em] uppercase text-slate-500">Agrotech Pvt Ltd</div>
    </div>
  </div>
);

const data = [
  { year: "2019", growth: 30 },
  { year: "2020", growth: 45 },
  { year: "2021", growth: 60 },
  { year: "2022", growth: 80 },
  { year: "2023", growth: 95 },
];

export default function AgrigenesisSite() {
  return (
    <div className="font-sans text-slate-800">
      {/* Header */}
      <header className="flex items-center justify-between p-4 shadow-md bg-white sticky top-0 z-50">
        <Logo className="h-16" />
        <nav className="space-x-4 hidden md:flex">
          <a href="#about" className="hover:text-green-600">About</a>
          <a href="#services" className="hover:text-green-600">Services</a>
          <a href="#growth" className="hover:text-green-600">Growth</a>
          <a href="#contact" className="hover:text-green-600">Contact</a>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="text-center py-20 bg-gradient-to-r from-green-100 to-green-50">
        <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1 }}>
          <Logo className="mx-auto mb-6" />
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Growing the Future of Agriculture</h1>
          <p className="text-lg text-slate-600 mb-6 max-w-2xl mx-auto">
            Agrigenesis Agrotech Pvt Ltd innovates at the intersection of farming, technology, and sustainability.
          </p>
          <a href="#contact" className="inline-block bg-green-600 text-white px-6 py-3 rounded-full shadow hover:bg-green-700 transition">Get in Touch</a>
        </motion.div>
      </section>

      {/* About Section */}
      <section id="about" className="py-16 px-6 md:px-16 bg-white">
        <div className="max-w-5xl mx-auto grid md:grid-cols-2 gap-10 items-center">
          <img src="/logo.png" alt="About Agrigenesis" className="rounded-2xl shadow-lg" />
          <div>
            <h2 className="text-3xl font-bold mb-4">About Us</h2>
            <p className="text-slate-600 mb-4">
              Agrigenesis Agrotech Pvt Ltd is a pioneering agricultural technology company dedicated to transforming farming practices with sustainable innovations.
            </p>
            <p className="text-slate-600">
              From advanced crop solutions to smart supply chains, we are committed to empowering farmers and ensuring food security for generations to come.
            </p>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-16 px-6 md:px-16 bg-green-50">
        <div className="max-w-6xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-12">Our Services</h2>
          <div className="grid md:grid-cols-4 gap-8">
            <div className="p-6 bg-white rounded-2xl shadow hover:shadow-lg transition">
              <Leaf className="w-12 h-12 text-green-600 mx-auto mb-4" />
              <h3 className="font-semibold mb-2">Sustainable Farming</h3>
              <p className="text-slate-600 text-sm">Eco-friendly practices for higher yields and healthier crops.</p>
            </div>
            <div className="p-6 bg-white rounded-2xl shadow hover:shadow-lg transition">
              <Factory className="w-12 h-12 text-green-600 mx-auto mb-4" />
              <h3 className="font-semibold mb-2">Agro Processing</h3>
              <p className="text-slate-600 text-sm">State-of-the-art facilities to add value to raw produce.</p>
            </div>
            <div className="p-6 bg-white rounded-2xl shadow hover:shadow-lg transition">
              <FlaskConical className="w-12 h-12 text-green-600 mx-auto mb-4" />
              <h3 className="font-semibold mb-2">Agri R&D</h3>
              <p className="text-slate-600 text-sm">Innovating solutions with biotechnology and smart farming.</p>
            </div>
            <div className="p-6 bg-white rounded-2xl shadow hover:shadow-lg transition">
              <Truck className="w-12 h-12 text-green-600 mx-auto mb-4" />
              <h3 className="font-semibold mb-2">Supply Chain</h3>
              <p className="text-slate-600 text-sm">Efficient distribution from farm to market with minimal waste.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Growth Section */}
      <section id="growth" className="py-16 px-6 md:px-16 bg-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-6">Our Growth</h2>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="year" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="growth" stroke="#16a34a" strokeWidth={3} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-16 px-6 md:px-16 bg-green-50">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold mb-6 text-center">Contact Us</h2>
          <div className="grid md:grid-cols-2 gap-10">
            <div className="space-y-4">
              <p className="flex items-center"><Phone className="mr-2 text-green-600" /> <a href="tel:+919422181508" className="hover:underline">+91-9422181508</a></p>
              <p className="flex items-center"><Mail className="mr-2 text-green-600" /> <a href="mailto:agrigenesisagrotech@gmail.com" className="hover:underline">agrigenesisagrotech@gmail.com</a></p>
              <p className="flex items-center"><MapPin className="mr-2 text-green-600" /> Pune, Maharashtra, India</p>
              <div className="flex space-x-4 mt-4">
                <a href="#" className="text-green-600 hover:text-green-800"><Linkedin /></a>
                <a href="#" className="text-green-600 hover:text-green-800"><Twitter /></a>
              </div>
            </div>
            <form className="space-y-4">
              <input type="text" placeholder="Your Name" className="w-full p-3 border rounded-xl" />
              <input type="email" placeholder="Your Email" className="w-full p-3 border rounded-xl" />
              <textarea placeholder="Your Message" rows="4" className="w-full p-3 border rounded-xl"></textarea>
              <button type="submit" className="bg-green-600 text-white px-6 py-3 rounded-full shadow hover:bg-green-700 transition">Send Message</button>
            </form>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-green-600 text-white text-center p-6">
        <Logo className="mx-auto mb-4" />
        <p>&copy; {new Date().getFullYear()} Agrigenesis Agrotech Pvt Ltd. All rights reserved.</p>
      </footer>
    </div>
  );
}